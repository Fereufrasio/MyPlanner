<?php
include('conexao.php');

if (isset($_POST['email']) || isset($_POST['senha'])) {
    if (strlen($_POST['email']) == 0) {
        echo "Preencha seu e-mail";
    } else if (strlen($_POST['senha']) == 0) {
        echo "Preencha sua senha";
    } else {
        $email = $mysqli->real_escape_string($_POST['email']);
        $senha = $mysqli->real_escape_string($_POST['senha']);

   
        $sql_code = "SELECT * FROM usuarios WHERE email = '$email'";
        $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: " . $mysqli->error);

        
        if ($sql_query->num_rows == 1) {
            $usuario = $sql_query->fetch_assoc();

            // Verificação de senha
            if (password_verify($senha, $usuario['senha'])) {
                if (!isset($_SESSION)) {
                    session_start();
                }

                $_SESSION['id'] = $usuario['id'];
                $_SESSION['nome'] = $usuario['nome'];

                header("Location: home.html");
                exit();
            } else {
                echo "Senha incorreta!";
            }
        } else {
            echo "Usuário não encontrado!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Todo App</title>
    <link rel="stylesheet" href="css/stylelogin.css">
</head>
<body>

    <header class="main-header">
        <nav class="navbar">
            <div class="logo">
                <a href="">MyPlanner</a>
            </div>
            <ul class="nav-menu">
                <li><a href="">Sobre</a></li>
                <li><a href="">Funcionalidades</a></li>
                <li><a href="">Lista de Tarefas</a></li>
                <li><a href="">Financeiro</a></li>
                <li><a href="">Bloco de Notas</a></li>
            </ul>
        </nav>
    </header>

    <div class="login-container">
        <div class="login-box">
            <h1>Login</h1>
            <form action="index.php" method="POST">
                <div class="input-group">
                    <label for="username">E-mail</label>
                    <input type="text" id="username" name="email" required>
                </div>
                <div class="input-group">
                    <label for="password">Senha</label>
                    <input type="password" id="password" name="senha" required>
                </div>
                <button type="submit">Entrar</button>
            </form>
            <p class="signup">Ainda não tem uma conta? <a href="cadastro.html">Cadastre-se</a></p>
        </div>
    </div>
</body>
</html>
