function calcularInvestimento() {
    const capitalInicial = parseFloat(document.getElementById("capitalInicial").value);
    const tipoInvestimento = document.getElementById("tipoInvestimento").value;
    const tipoJuros = document.getElementById("tipoJuros").value;
    let taxaJuros;

    // Define a taxa de juros com base no tipo de investimento
    switch (tipoInvestimento) {
        case "cdb":
            taxaJuros = 5 / 100; // 5% ao ano
            break;
        case "tesouro":
            taxaJuros = 6 / 100; // 6% ao ano
            break;
        case "acoes":
            taxaJuros = 10 / 100; // 10% ao ano
            break;
        case "personalizado":
            taxaJuros = parseFloat(document.getElementById("taxaJuros").value) / 100;
            if (isNaN(taxaJuros)) {
                document.getElementById("resultado").innerHTML = "Por favor, insira uma taxa de juros válida.";
                return;
            }
            break;
        default:
            taxaJuros = 0;
    }

    const periodo = parseInt(document.getElementById("periodo").value);
    const aporteMensal = parseFloat(document.getElementById("aporteMensal").value) || 0;

    // Verificações adicionais para garantir entradas válidas
    if (isNaN(capitalInicial) || isNaN(periodo) || capitalInicial < 0 || periodo <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos para o capital inicial e o período.";
        return;
    }

    let montanteFinal = capitalInicial;
    let historicoValores = [capitalInicial];

    // Cálculo do montante final com base no tipo de juros
    if (tipoJuros === "composto") {
        // Juros Compostos - Aplicado sobre o montante atualizado mensalmente
        for (let i = 1; i <= periodo; i++) {
            montanteFinal = (montanteFinal + aporteMensal) * (1 + taxaJuros); // taxa de juros mensal
            historicoValores.push(montanteFinal);
        }
    } else if (tipoJuros === "simples") {
        // Juros Simples - Calculado apenas sobre o capital inicial
        const jurosMensalFixo = capitalInicial * taxaJuros;
        for (let i = 1; i <= periodo; i++) {
            montanteFinal += jurosMensalFixo + aporteMensal;
            historicoValores.push(montanteFinal);
        }
    } else if (tipoJuros === "nenhum") {
        // Sem Juros - Apenas soma dos aportes mensais
        for (let i = 1; i <= periodo; i++) {
            montanteFinal += aporteMensal;
            historicoValores.push(montanteFinal);
        }
    }

    document.getElementById("resultado").innerHTML = `Após ${periodo} meses, seu investimento será de R$ ${montanteFinal.toFixed(2)}.`;

    // Atualizar o gráfico com valores de evolução
    atualizarGrafico(historicoValores);
    
    // Salvar no histórico com os dados da simulação
    salvarHistorico({ 
        capitalInicial, 
        taxaJuros: (taxaJuros * 100).toFixed(2), // Armazena a taxa de juros como percentual
        periodo, 
        aporteMensal, 
        tipoJuros, 
        montanteFinal 
    });
    
    mostrarHistorico();
}

// Função para atualizar o gráfico
function atualizarGrafico(valores) {
    const ctx = document.getElementById('graficoInvestimento').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: valores.map((_, index) => `Mês ${index}`),
            datasets: [{
                label: 'Evolução do Investimento',
                data: valores,
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                fill: false,
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: { title: { display: true, text: 'Mês' }},
                y: { title: { display: true, text: 'Valor (R$)' }}
            }
        }
    });
}

// Função para salvar o histórico de simulações no Local Storage
function salvarHistorico(simulacao) {
    let historico = JSON.parse(localStorage.getItem('historicoInvestimentos')) || [];
    historico.push(simulacao);
    localStorage.setItem('historicoInvestimentos', JSON.stringify(historico));
}

// Função para exibir o histórico de simulações
function mostrarHistorico() {
    const historico = JSON.parse(localStorage.getItem('historicoInvestimentos')) || [];
    const listaHistorico = document.getElementById('historico');
    listaHistorico.innerHTML = '';

    historico.forEach((simulacao, index) => {
        const item = document.createElement('li');
        item.textContent = `Simulação ${index + 1}: Capital Inicial: R$ ${simulacao.capitalInicial}, Taxa de Juros: ${simulacao.taxaJuros}%, Período: ${simulacao.periodo} meses, Aporte Mensal: R$ ${simulacao.aporteMensal}, Tipo de Juros: ${simulacao.tipoJuros}, Montante Final: R$ ${simulacao.montanteFinal.toFixed(2)}`;
        listaHistorico.appendChild(item);
    });
}

// Função para limpar o histórico de simulações
function limparHistorico() {
    localStorage.removeItem('historicoInvestimentos');
    mostrarHistorico();
}

// Mostrar histórico ao carregar a página
mostrarHistorico();
