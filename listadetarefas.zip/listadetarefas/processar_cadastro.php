<?php
include('conexao.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $email = $mysqli->real_escape_string($_POST['email']);
    $senha = $mysqli->real_escape_string($_POST['senha']);

    // Criptografia
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (email, senha) VALUES ('$email', '$senhaHash')";
    
    if ($mysqli->query($sql) === TRUE) {
        echo "Cadastro realizado com sucesso!";
        
        header("Location: index.php");
        exit();
    } else {
        echo "Erro: " . $sql . "<br>" . $mysqli->error;
    }
}

$mysqli->close(); 
?>

